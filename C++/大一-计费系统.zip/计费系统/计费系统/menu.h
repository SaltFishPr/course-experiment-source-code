#pragma once
#include<string>
void outputMenu();
bool inputCardNo(string& strNo);
bool inputCardPwd(string& strPwd);
bool inputCardBalance(float&fBalance);
bool inputNoPwd(string&strNo,string&strPwd);
bool inputNoPwdBalance(string&strNo, string&strPwd, float&fBalance);