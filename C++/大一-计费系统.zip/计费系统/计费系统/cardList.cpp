#include"stdafx.h"
#include"model.h"
#include"global.h"
#include"tool.h"
#include"cardList.h"
int addNewCard(string strNo, string strPwd, float fBalance, CardNode** ppCardNodeHead)
{
	int nCardIndex = 0;
	if (cardIsExist(strNo, nCardIndex,*ppCardNodeHead) != NULL)
		return FINDCARD;

	Card card;
	strcpy(card.aName, strNo.c_str());
	strcpy(card.aPwd, strPwd.c_str());
	card.fBalance = fBalance;
	//�����¿�ʱ���ۼƽ����ڿ������
	card.fTotalUse = card.fBalance;
	card.nStatus = UNUSE;//��״̬
	card.nUseCount = 0;//ʹ�ô���
	//����ʱ�䣬���ʹ��ʱ�䶼Ĭ��Ϊ��ǰʱ��
	card.tStart = card.tLast = time(NULL);

	CardNode* pCardNode = new CardNode;
	pCardNode->data = card;

	CardNode *pCardNodeHead = *ppCardNodeHead;
	CardNode *pCardNodeTail = *ppCardNodeHead;

	if (pCardNodeHead == NULL)
	{
		//��һ�ſ���ͨ��ppCardNodeHead����ָ̬�뷵��
		pCardNodeHead = pCardNode;
		pCardNodeTail = pCardNode;
		*ppCardNodeHead = pCardNode;
	}
	else
	{
		pCardNodeTail = pCardNodeHead;
		while (pCardNodeTail->next != NULL)
			pCardNodeTail = pCardNodeTail->next;
		pCardNodeTail->next = pCardNode;
		pCardNodeTail = pCardNode;
	}

	pCardNodeTail->next = NULL;

	saveCard(&pCardNode->data, CARDPATH);

	return SUCCESS;
}
CardNode* CardListInit(const string cardFilename)//���ļ��еĿ���Ϣ�ָ�������
{
	ifstream cardfile(cardFilename, ios::binary);
	CardNode *pCardNode, *pCardNodeHead, *pCardNodeTail;
	Card card;

	if (!cardfile.is_open())
	{
		return NULL;
	}

	pCardNodeHead = NULL;
	pCardNodeTail = NULL;

	while (1)
	{
		cardfile.read((char*)&card, sizeof(Card));
		if (cardfile.eof())
		{
			break;
		}
		pCardNode = new CardNode;
		pCardNode->data = card;
		if (pCardNodeHead == NULL)
		{
			pCardNodeHead = pCardNode;
			pCardNodeTail = pCardNode;
		}
		else
		{
			pCardNodeTail->next = pCardNode;
			pCardNodeTail = pCardNode;

		}
	}
	pCardNodeTail->next = NULL;
	cardfile.close();

	return pCardNodeHead;
}
void displayCard(CardNode* pCardNodeHead)
{
	if (pCardNodeHead == NULL)
	{
		cout << endl << endl << "һ���ϻ�����û�У�" << endl << endl;
		return;
	}

	cout << "����\t״̬\t���\t�ۼ�ʹ��\tʹ�ô���\t�ϴ�ʹ��ʱ��\n";
	CardNode*pCur = pCardNodeHead;
	while(pCur!=NULL)
	{
		char aLastTime[TIMELENGTH] = { 0 };
		timeToString((pCur->data).tLast, aLastTime);
		cout << pCur->data.aName << "\t";
		if (pCur->data.nStatus == USING)
			cout << "�ϻ�\t";
		else if (pCur->data.nStatus == UNUSE)
			cout << "δ�ϻ�\t";
		else if (pCur->data.nStatus == INVALID)
			cout << "ע��\t";
		else
			cout << "����\t";
		cout << pCur->data.fBalance << "\t";
		cout << pCur->data.fTotalUse << "\t\t";
		cout << pCur->data.nUseCount << "\t\t";
		cout << aLastTime << endl;
		/*
		char aTime[TIMELENGTH] = { 0 };
		timeToString((pCur->data).tStart, aTime);
		cout << aTime << endl;
		*/
		
		pCur = pCur->next;
	}
}
Card* cardIsExist(string strNo, int &nCardIndex, CardNode* const pCardNodeHead)//���Ƿ����
{
	CardNode *pCardNode = pCardNodeHead;

	nCardIndex = 0;
	while(pCardNode!=NULL)
	{
		if (strcmp(pCardNode->data.aName, strNo.c_str()) == 0)
		{
			return &(pCardNode->data);
		}
		pCardNode = pCardNode->next;
		nCardIndex++;
	}
	return NULL;
}
bool saveCard(const Card* pCard, const string pPath)
{
	ofstream ofile(pPath, ios::binary | ios::app);

	ofile.write((char*)pCard, sizeof(Card));
	ofile.close();

	return true;
}