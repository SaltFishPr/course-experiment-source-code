#pragma once
#include<time.h>
#include<fstream>
#include"model.h"
void timeToString(time_t t, char* pBuf);
time_t stringToTime(const char* pTime);
