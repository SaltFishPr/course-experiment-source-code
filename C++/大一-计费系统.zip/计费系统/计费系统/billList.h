#pragma once
BillingNode* BillListInit(const string billingFilename);
bool saveBilling(const Billing* pBilling, const string pPath);
Billing* billingIsExist(string strNo, int&nBillingIndex, BillingNode*pBillingNodeHead);
double getAmount(time_t tStart);