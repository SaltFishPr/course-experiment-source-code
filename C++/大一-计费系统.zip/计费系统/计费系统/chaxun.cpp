#include"stdafx.h"
#include"cardList.h"
#include"billList.h"
#include"MoneyList.h"
#include"model.h"
#include"tool.h"
#include"global.h"
void cha1(time_t t1,time_t t2,MoneyNode*pMoneyNodeHead)//��ֵ�����ѯ
{
	MoneyNode*pMoneyNode = pMoneyNodeHead;
	while (pMoneyNode != NULL)
	{
		if (pMoneyNode->data.time >= t1&& pMoneyNode->data.time <= t2)
			break;
		pMoneyNode = pMoneyNode->next;
	}
	if (pMoneyNode == NULL)
	{
		cout << "�޽��׼�¼��" << endl;
		return;
	}
	cout << "��ʱ����ڳ�ֵ�˷�:\t��ֵ-0/�˷�-1" << endl;
	while (pMoneyNode != NULL)
	{
		if (pMoneyNode->data.time >= t1&& pMoneyNode->data.time <= t2)
			cout << pMoneyNode->data.fBalance << "\t" << pMoneyNode->data.choice << endl;
		pMoneyNode = pMoneyNode->next;
	}
	return;
}
void cha2(time_t t1, time_t t2, CardNode*pCardNodeHead)//���������ѯ
{
	CardNode*pCardNode = pCardNodeHead;
	char aTime[TIMELENGTH] = { 0 };
	
	while (pCardNode != NULL)
	{
		if (pCardNode->data.tStart >= t1&& pCardNode->data.tStart <= t2)
			break;
		pCardNode = pCardNode->next;
	}
	if (pCardNode == NULL)
	{
		cout << "�޽��׼�¼��" << endl;
		return;
	}
	cout << "��ʱ����ڿ���:" << endl;
	while (pCardNode != NULL)
	{
		if (pCardNode->data.tStart >= t1&& pCardNode->data.tStart <= t2)
		{
			timeToString((pCardNode->data).tStart, aTime);
			cout << pCardNode->data.aName << "\t" << aTime << endl;
		}
		pCardNode = pCardNode->next;
	}
	return;
}
void cha3(time_t t1, time_t t2, BillingNode*pBillingNodeHead)//�ϻ������ѯ
{
	BillingNode*pBillingNode = pBillingNodeHead;
	char aTime[TIMELENGTH] = { 0 };
	while (pBillingNode != NULL)
	{
		if (pBillingNode->data.tStart >= t1&& pBillingNode->data.tStart <= t2)
			break;
		pBillingNode = pBillingNode->next;
	}
	if (pBillingNode == NULL)
	{
		cout << "�޽��׼�¼��" << endl;
		return;
	}
	cout << "��ʱ����ڿ���:" << endl;
	while (pBillingNode != NULL)
	{
		if (pBillingNode->data.tStart >= t1&& pBillingNode->data.tStart <= t2)
		{
			timeToString((pBillingNode->data).tStart, aTime);
			cout << pBillingNode->data.fAmount << "\t" << aTime << endl;
		}
		pBillingNode = pBillingNode->next;
	}
	return;
}
void cha4(time_t t1, time_t t2, CardNode*pCardNodeHead)
{
	CardNode*pCardNode = pCardNodeHead;
	int total=0;
	while (pCardNode != NULL)
	{
		if (pCardNode->data.tStart >= t1&& pCardNode->data.tStart <= t2)
			break;
		pCardNode = pCardNode->next;
	}
	if (pCardNode == NULL)
	{
		cout << "�޽��׼�¼��" << endl;
		return;
	}
	while (pCardNode != NULL)
	{
		if (pCardNode->data.tStart >= t1&& pCardNode->data.tStart <= t2)
			total += pCardNode->data.fTotalUse;
		pCardNode = pCardNode->next;
	}
	cout <<"��Ӫҵ��Ϊ��"<< total << endl;
	return;
}
