#include"stdafx.h"
#include"model.h"
#include"global.h"
#include<fstream>
#include"MoneyList.h"
#include"cardList.h"
#include"service.h"
#include"menu.h"
MoneyNode* MoneyListInit(const string moneyFilename)//���ļ��еĳ�ֵ�˷���Ϣ�ָ�������
{
	ifstream moneyfile(moneyFilename, ios::binary);

	MoneyNode *pMoneyNode, *pMoneyNodeHead, *pMoneyNodeTail;
	Money money;

	if (!moneyfile.is_open())
	{
		return NULL;
	}

	pMoneyNodeHead = NULL;
	pMoneyNodeTail = NULL;
	
	while (1)
	{
		moneyfile.read((char*)&money, sizeof(Money));
		if (moneyfile.eof())
			break;

		pMoneyNode = new MoneyNode;
		pMoneyNode->data = money;

		if (pMoneyNodeHead == NULL)
		{
			pMoneyNodeHead = pMoneyNode;
			pMoneyNodeTail = pMoneyNode;
		}
		else
		{
			pMoneyNodeTail->next = pMoneyNode;
			pMoneyNodeTail = pMoneyNode;
		}
	}
	pMoneyNodeTail->next = NULL;

	moneyfile.close();

	return pMoneyNodeHead;

}

bool saveMoney(const Money* pMoney, const string pPath)//�����ֵ�˷�����
{
	ofstream ofile(pPath, ios::binary | ios::app);
	
	ofile.write((char*)pMoney, sizeof(Money));
	ofile.close();

	return true;
}

Money* moneyIsExist(string strNo, int&nMoneyIndex, MoneyNode*pMoneyNodeHead)//�жϿ��ļƷ���Ϣ�Ƿ���ڣ������ؼƷ��������еĽڵ�
{
	MoneyNode *pMoneyNode = pMoneyNodeHead;

	nMoneyIndex = 0;
	while (pMoneyNode != NULL)
	{
		if (strcmp(pMoneyNode->data.aCardName, strNo.c_str()) == 0 )
		{
			return &(pMoneyNode->data);
		}
		pMoneyNode = pMoneyNode->next;
		nMoneyIndex++;
	}
	return NULL;
}

void MoneyListInfo(string strNo, int choice, float fBalance, MoneyNode ** ppMoneyNodeHead)
{
	//Fill data
	Money money;
	strcpy(money.aCardName, strNo.c_str());
	money.choice = choice;
	money.fBalance = fBalance;
	money.time = time(NULL);
	saveMoney(&money, MONEYPATH);

	//Construct Node
	MoneyNode* pMoneyNode = new MoneyNode;
	pMoneyNode->data = money;

	//Insert Node
	MoneyNode *pMoneyNodeHead = *ppMoneyNodeHead;
	MoneyNode *pMoneyNodeTail = *ppMoneyNodeHead;

	if (pMoneyNodeHead == NULL)
	{
		pMoneyNodeHead = pMoneyNode;
		pMoneyNodeTail = pMoneyNode;
		*ppMoneyNodeHead = pMoneyNode;
	}
	else
	{
		pMoneyNodeTail = pMoneyNodeHead;
		while (pMoneyNodeTail->next != NULL)
			pMoneyNodeTail = pMoneyNodeTail->next;
		pMoneyNodeTail->next = pMoneyNode;
		pMoneyNodeTail = pMoneyNode;
	}
	pMoneyNodeTail->next = NULL;
	saveMoney(&pMoneyNode->data, MONEYPATH);
}
void changefBalance(string strNo,string strPwd,CardNode *pCardNode, float fBalance, const int choice)//���Ŀ��н��
{
	if (choice == 0)
	{
		if (fBalance > 0)
		{
			pCardNode->data.fBalance += fBalance;
			pCardNode->data.fTotalUse += fBalance;
			pCardNode->data.tLast = time(NULL);
		}
		else cout << "����ȷ�����ֵ��" << endl;

	}
	else if (choice == 1)
	{
		if (fBalance > 0)
		{
			if (fBalance > pCardNode->data.fBalance)
				cout << "�������㣡" << endl;
			else
			{
				pCardNode->data.fBalance -= fBalance;
				pCardNode->data.fTotalUse -= fBalance;
				pCardNode->data.tLast = time(NULL);
			}
		}
		else cout << "����ȷ�����ֵ��" << endl;
	}
}
void changeInfo(string strNo,string strPwd, float fBalance, CardNode *pCardNodeHead, const int choice,Card*pCard,int nCardIndex)//����Ϣ�ı亯��
{
	CardNode*pCardNode = pCardNodeHead;
	while (strcmp(pCardNode->data.aName, strNo.c_str()) != 0)
		pCardNode = pCardNode->next;
	changefBalance(strNo,strPwd,pCardNode, fBalance, choice);
	updateCard(pCard, CARDPATH, nCardIndex);
}



/*
double chongzhiInfo(string strNo, Money* pInfo, float fBalance, CardNode * const pCardNodeHead, MoneyNode* const pMoneyNodeHead, MoneyNode**  ppMoneyNodeHead)//��ֵ�˷���Ϣ�޸�
{
	Money money;
	int nCardIndex;
	Card* pCard = cardIsExist(strNo, nCardIndex, pCardNodeHead);

	if (pCard == NULL)
		return NOFINDCARD;//δ�ҵ���

	int nMoneyIndex;
	Money* pMoney = moneyIsExist(strNo, nMoneyIndex, pMoneyNodeHead);
	if (pMoney->a == 0)//��ֵ
	{
		pCard->fBalance += fBalance;
		pCard->tLast = time(NULL);
		updateCard(pCard, CARDPATH, nCardIndex);
		strcpy(pInfo->aCardName, strNo.c_str());//����
		pInfo->fBalance = (float)fBalance;//��ֵ���
		pInfo->time = time(NULL);//��ֵʱ��

	}
	if (pMoney->a == 1)
	{
		pCard->fBalance -= fBalance;
		pCard->tLast = time(NULL);
		updateCard(pCard, CARDPATH, nCardIndex);
		strcpy(pInfo->aCardName, strNo.c_str());//����
		pInfo->fBalance = -(float)fBalance;//�˷ѽ��
		pInfo->time = time(NULL);//�˷�ʱ��
	}

	saveMoney(&money, MONEYPATH);
	MoneyNode* pMoneyNode = new MoneyNode;
	pMoneyNode->data = money;

	MoneyNode* pMoneyNodeTail = *ppMoneyNodeHead;

	if (*ppMoneyNodeHead == NULL)
	{
		*ppMoneyNodeHead = pMoneyNode;
		pMoneyNodeTail = pMoneyNode;

	}
	else
	{
		while (pMoneyNodeTail->next != NULL)
			pMoneyNodeTail = pMoneyNodeTail->next;
		pMoneyNodeTail->next = pMoneyNode;
		pMoneyNodeTail = pMoneyNode;
	}
	pMoneyNodeTail->next = NULL;
}
*/
