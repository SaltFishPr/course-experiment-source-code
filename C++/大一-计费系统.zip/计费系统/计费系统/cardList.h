#pragma once
#include<iostream>
#include"stdafx.h"
#include"model.h"
using namespace std;
int addNewCard(string strNo, string strPwd, float fBalance, CardNode** ppCardNodeHead);
Card* cardIsExist(string strNo, int &nCardIndex, CardNode* const pCardNodeHead);
CardNode* CardListInit(const string cardFilename);
bool saveCard(const Card* pCard, const string pPath);
void displayCard(CardNode* pCardNodeHead);
