#pragma once
#include"stdafx.h"
#include"cardList.h"
#include"billList.h"
#include"MoneyList.h"
#include"model.h"
#include"global.h"
void cha1(time_t t1, time_t t2, MoneyNode*pMoneyNodeHead);
void cha2(time_t t1, time_t t2, CardNode*pCardNodeHead);
void cha3(time_t t1, time_t t2, BillingNode*pBillingNodeHead);
void cha4(time_t t1, time_t t2, CardNode*pCardNodeHead);