#pragma once
MoneyNode* MoneyListInit(const string moneyFilename);
bool saveMoney(const Money* pMoney, const string pPath);
Money* moneyIsExist(string strNo, int&nMoneyIndex, MoneyNode*pMoneyNodeHead);
void MoneyListInfo(string strNo, int choice, float fBalance, MoneyNode ** ppMoneyNodeHead);
void changeInfo(string strNo,string strPwd, float fBalance, CardNode *pCardNodeHead, const int choice,Card*pCard, int nCardIndex);
void changefBalance(string strNo,string strPwd, CardNode *pCardNode, float fBalance, const int choice);