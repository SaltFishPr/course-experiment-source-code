#pragma once
#include"model.h"
void addCard(CardNode** ppCardNodeHead);
void queryCard(CardNode* const pCardNodeHead);
void clearData(CardNode* pCardNodeHead);
bool updateCard(const Card* pCard, const string pPath, int nCardIndex);
void shangJi(CardNode* pCardNodeHead, BillingNode **ppBillingNodeHead);
int logon(string strNo, string strPwd, LogonInfo*pInfo, CardNode*pCardNodeHead, BillingNode **ppBillingNodeHead);
void xiaJi(CardNode* pCardNodeHead, BillingNode* pBillingNodeHead);
int settle(string strNo, string strPwd, SettleInfo* pInfo, CardNode* const pCardNodeHead, BillingNode* const pBillingNodeHead);
bool updateBilling(const Billing* pBilling, const string pPath, int nBillingIndex);
bool updateMoney(const Money* pMoney, const string pPath, int nMoneyIndex);
void chongtui(CardNode* pCardNodeHead);
void destory(CardNode* pCardNodeHead);
void restart(CardNode* pCardNodeHead);
void chaxun(CardNode* pCardNodeHead, BillingNode*pBillingNodeHead, MoneyNode*pMoneyNodeHead);