package All.Client;

import All.Client.Frame.System_Login_Frame;

public class App {

    public static void main(String[] args) {

        System_Login_Frame login_frame = new System_Login_Frame();
        login_frame.setVisible(true);

    }
}