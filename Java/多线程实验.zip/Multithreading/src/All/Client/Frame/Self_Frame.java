package All.Client.Frame;

import All.Client.App;
import All.Domain.User;
import All.Server.DAO.UserDao;
import All.Socket.Client;
import All.util.CommandTranser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Self_Frame extends Base_Frame {
    private JPanel SelfManagementPanel;
    private JTextField nameTextField;
    private JPasswordField oldPasswordField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;
    private JTextField roleTextField;
    private JButton okButton;
    private JButton backButton;

    public Self_Frame(User user) {
        currentUser = user;
        setTitle("个人信息管理");
        getContentPane().add(SelfManagementPanel,BorderLayout.CENTER);
        setSize(400, 300);
        Toolkit toolkit = getToolkit();
        Dimension dimension = toolkit.getScreenSize();
        int screenHeight = dimension.height;
        int screenWidth = dimension.width;
        int frm_Height = this.getHeight();
        int frm_width = this.getWidth();
        this.setLocation((screenWidth - frm_width) / 2,
                (screenHeight - frm_Height) / 2);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                okButtonAction(e);
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonAction(e);
            }
        });
        showUserInfoToPanel();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    }

//    public static void launch() {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Self_Frame().setVisible(true);
//            }
//        });
//    }

    private void okButtonAction(ActionEvent evt) {
        String username = currentUser.getUsername();
        String oldPassword = new String(oldPasswordField.getPassword());
        String newPassword = new String(newPasswordField.getPassword());
        String okNewPassword = new String(confirmPasswordField.getPassword());
        User user = new User();
        if (newPassword == null || newPassword.equals("")) {
            JOptionPane.showMessageDialog(this, "原密码不能为空！！！");
        }
        else if (oldPassword.equals(currentUser.getPassword())) {
            if (newPassword == null || newPassword.equals("")) {
                JOptionPane.showMessageDialog(this, "新密码不能为空！！！");
            }
            else if (okNewPassword == null || okNewPassword.equals("")) {
                JOptionPane.showMessageDialog(this, "确认新密码不能为空！！！");
            }
            else if (!newPassword.equals(okNewPassword)) {
                JOptionPane.showMessageDialog(this, "新密码和确认新密码不一致！！！");
            }
            else {
                try {
                    if (JOptionPane.showConfirmDialog(this, "确定要修改密码吗？\t\n单击确定按钮将修改。", "确认对话框", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                        user.setUsername(username);
                        user.setPassword(newPassword);
                        user.setRole(currentUser.getRole());
                        CommandTranser commandTranser;
                        commandTranser = Client.transer("changeSelfInfo",user);

                        JOptionPane.showMessageDialog(this, commandTranser.getResult());
                        currentUser.setPassword(newPassword);
                    }
                }
                catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "数据库异常。\t\n" + ex.getMessage());
                }
            }
        }
        else {
            JOptionPane.showMessageDialog(this, "原密码不正确！！！");
        }
        oldPasswordField.setText(null);
        newPasswordField.setText(null);
        confirmPasswordField.setText(null);
        oldPasswordField.requestFocus();
    }

    private void showUserInfoToPanel(){
        nameTextField.setText(currentUser.getUsername());
        roleTextField.setText(currentUser.getRole());
    }

    private void cancelButtonAction(ActionEvent evt){
        this.dispose();
    }
}
