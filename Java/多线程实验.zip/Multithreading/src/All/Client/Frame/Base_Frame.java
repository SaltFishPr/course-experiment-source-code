package All.Client.Frame;

import All.Domain.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Base_Frame extends JFrame {
    private static final long serialVersionUID = 1L;

    protected User currentUser;

    public User getCurrentUser() {
        return currentUser;
    }
    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

}

class MyTableModel extends DefaultTableModel {

     MyTableModel(String[][] tableValue, String[] colName) {
        super(tableValue,colName);
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
}