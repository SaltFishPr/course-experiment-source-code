package All.Client.Frame;

import All.Domain.User;
import All.Server.DAO.UserDao;
import All.Socket.Client;
import All.util.CommandTranser;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class User_Management_Frame extends Base_Frame{

    private MyTableModel tableModel;
    private JPanel mainPanel;
    private JTabbedPane tabbedPane1;
    private JButton add;
    private JButton cancel1;
    private JTextField name1;
    private JComboBox role1;
    private JPasswordField password1;
    private JButton revise;
    private JPasswordField password2;
    private JComboBox role2;
    private JTable jTable;
    private JComboBox name2;
    private JButton cancel2;
    private JButton delete;
    private JButton goback;

    public User_Management_Frame(User user) {
        currentUser = user;
        setTitle("用户管理界面");
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        setSize(300, 300);
        Toolkit toolkit = getToolkit();
        Dimension dimension = toolkit.getScreenSize();
        int screenHeight = dimension.height;
        int screenWidth = dimension.width;
        int frm_Height = this.getHeight();
        int frm_width = this.getWidth();
        this.setLocation((screenWidth - frm_width) / 2,
                (screenHeight - frm_Height) / 2);
        jTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //事件监听
        tabbedPane1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                tabbedPane1StateChanged(e);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = name1.getText();
                String password = String.valueOf(password1.getPassword());
                String role = (String) role1.getSelectedItem();
                try {
                    if(JOptionPane.showConfirmDialog(null,"确定新增用户吗？\t\n单击确定按钮将新增。", "确认对话框",JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                        User user = new User(name,password,role);

                        CommandTranser commandTranser;
                        commandTranser = Client.transer("register",user);

                        JOptionPane.showMessageDialog(null,commandTranser.getResult());
                        name1.setText("");
                        password1.setText("");
                        role1.setSelectedIndex(-1);
                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
        cancel1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                name1.setText("");
                password1.setText("");
                role1.setSelectedIndex(-1);
            }
        });
        name2.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                name2comboBoxItemStateChanged(e);
            }
        });
        revise.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reviseButtonAction(e);
            }
        });
        cancel2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonAction(e);
            }
        });
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteButtonAction(e);
            }
        });
        goback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gobackButtonAction(e);
            }
        });
    }
    //操作函数

    void gobackButtonAction(ActionEvent evt){
        this.dispose();
    }

    private void deleteButtonAction(ActionEvent evt){
        try{
            if (JOptionPane.showConfirmDialog(this, "确定要删除用户吗？\t\n单击确定按钮将删除。", "确认对话框", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                int currentRow = jTable.getSelectedRow();
                if (currentRow == -1) {
                    JOptionPane.showMessageDialog(null, "请选择一行！", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                String username = "";
                Object object = tableModel.getValueAt(currentRow, 0);
                System.out.println(currentRow);
                if (object != null) {
                    username = object.toString();
                }
                User user = null;

                CommandTranser commandTranser;
                commandTranser = Client.transer("find",username);
                user = (User) commandTranser.getData();
                commandTranser = Client.transer("deleteUser",user);
                JOptionPane.showMessageDialog(this, commandTranser.getResult());
                showUserInfoToTable();
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    private void cancelButtonAction(ActionEvent evt) {
        this.dispose();
    }

    private void reviseButtonAction(ActionEvent evt){
        String name = (String)name2.getSelectedItem();
        String password = new String(password2.getPassword());
        String role = (String)role2.getSelectedItem();
        try {
            if (JOptionPane.showConfirmDialog(this,"确定要修改信息吗？\t\n单击确定按钮将修改。", "确认对话框", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                User user = new User(name,password,role);
                CommandTranser commandTranser;
                commandTranser = Client.transer("updateUser",user);

                JOptionPane.showMessageDialog(null,commandTranser.getResult());
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    private void name2comboBoxItemStateChanged(ItemEvent evt){
        User user;
        if (evt.getStateChange() == ItemEvent.SELECTED) {
            try{
                CommandTranser commandTranser;
                commandTranser = Client.transer("find",(String)evt.getItem());
                user = (User) commandTranser.getData();
                password2.setText(user.getPassword());
                role2.setSelectedItem(user.getRole());
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    private void tabbedPane1StateChanged(ChangeEvent evt) {
        if(tabbedPane1.getSelectedIndex()==0){

        }
        if(tabbedPane1.getSelectedIndex()==1){
            addUserToComboBox();
        }
        if(tabbedPane1.getSelectedIndex()==2){
            showUserInfoToTable();
        }

    }

    public void setTabSeq(int index){
        tabbedPane1.setSelectedIndex(index);
    }

    public void addUserToComboBox() {
        try {
            name2.removeAllItems();
            CommandTranser commandTranser;
            commandTranser = Client.transer("findAllOnes",null);
            List<User> users = (List<User>)commandTranser.getData();
            for (User user : users) {
                name2.addItem(user.getUsername());
            }

        }catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void showUserInfoToTable() {
        try {
            String[] colName = {"用户名", "口令", "角色"};
            String[][] tableValue = new String[20][3];
            CommandTranser commandTranser;
            commandTranser = Client.transer("findAllOnes",null);
            List<User> users = (List<User>)commandTranser.getData();
            for (int row = 0; row < users.size(); row++) {
                User user = users.get(row);
                tableValue[row][0]=user.getUsername();
                tableValue[row][1]=user.getPassword();
                tableValue[row][2]=user.getRole();
            }
            tableModel = new MyTableModel(tableValue, colName);
            jTable.setModel(tableModel);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
