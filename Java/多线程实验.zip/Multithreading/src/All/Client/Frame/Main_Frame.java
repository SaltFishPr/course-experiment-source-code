package All.Client.Frame;

import All.Client.App;
import All.Domain.User;
import All.Socket.Client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main_Frame extends Base_Frame{
    private JPanel mainPanel;
    private JMenuBar menuBar;
    private JMenu menuUser,menuFile,menuSelf;
    private JMenuItem menuItem_modUser,menuItem_delUser,menuItem_addUser, menuItem_listDoc,menuItem_upDoc,menuItem_downDoc, menuItem_querySelf,menuItem_modSelf;

    private User_Management_Frame userframe=null;
    private Self_Frame selfframe=null;
    private File_Frame fileframe=null;
    public Main_Frame(User user) {
        currentUser = user;
        InitFrame();
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        menuUser = new JMenu("用户管理");
        menuBar.add(menuUser);

        menuItem_modUser = new JMenuItem("修改用户");
        menuItem_modUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_modUserActionPerformed(e);
            }
        });
        menuUser.add(menuItem_modUser);

        menuItem_delUser = new JMenuItem("删除用户");
        menuItem_delUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_delUserActionPerformed(e);
            }
        });
        menuUser.add(menuItem_delUser);

        menuItem_addUser = new JMenuItem("新增用户");
        menuItem_addUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_addUserActionPerformed(e);
            }
        });
        menuUser.add(menuItem_addUser);

        menuFile = new JMenu("档案管理");
        menuBar.add(menuFile);

        menuItem_upDoc = new JMenuItem("档案上传");
        menuItem_upDoc.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_upDocActionPerformed(e);
            }
        });
        menuFile.add(menuItem_upDoc);

        menuItem_downDoc = new JMenuItem("档案下载");
        menuItem_downDoc.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_downDocActionPerformed(e);
            }
        });
        menuFile.add(menuItem_downDoc);

        menuSelf = new JMenu("个人信息管理");
        menuBar.add(menuSelf);

        menuItem_modSelf = new JMenuItem("信息修改");
        menuItem_modSelf.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_modSelfActionPerformed(e);
            }
        });
        menuSelf.add(menuItem_modSelf);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                Client.closeConnect();
                System.exit(0);
            }
        });

        menuItem_modUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuItem_modUserActionPerformed(e);
            }
        });
        menuItem_delUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuItem_delUserActionPerformed(e);
            }
        });
        menuItem_addUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuItem_addUserActionPerformed(e);
            }
        });

        menuItem_downDoc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuItem_downDocActionPerformed(e);
            }
        });
        menuItem_upDoc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuItem_upDocActionPerformed(e);
            }
        });

        menuItem_modSelf.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuItem_modSelfActionPerformed(e);
            }
        });

        setFrameByRole();
    }

    private void setFrameByRole() {
        if (currentUser.getRole().equals("administrator")) {
            setAdminFrame();
        } else if (currentUser.getRole().equals("operator")) {
            setOperatorFrame();
        } else {
            setBrowserFrame();
        }
    }

    public void setAdminFrame(){
        setTitle("系统管理员界面");
        menuItem_upDoc.setEnabled(false);
    }

    public void setOperatorFrame(){
        setTitle("档案录入员界面");
        menuUser.setEnabled(false);
    }

    public void setBrowserFrame(){
        setTitle("档案浏览员界面");
        menuUser.setEnabled(false);
        menuItem_upDoc.setEnabled(false);
    }

    private void menuItem_modSelfActionPerformed(ActionEvent e) {
        if (selfframe==null){
            selfframe= new Self_Frame(currentUser);
        }
        selfframe.setVisible(true);
    }

    private void menuItem_downDocActionPerformed(ActionEvent e) {
        if (fileframe==null){
            fileframe= new File_Frame(currentUser);
        }
        fileframe.setTabSeq(1);
        fileframe.setVisible(true);
    }

    private void menuItem_upDocActionPerformed(ActionEvent e) {
        if (fileframe==null){
            fileframe= new File_Frame(currentUser);
        }
        fileframe.setTabSeq(0);
        fileframe.setVisible(true);
    }

    private void menuItem_addUserActionPerformed(ActionEvent e) {
        if (userframe==null){
            userframe= new User_Management_Frame(currentUser);
        }
        userframe.setTabSeq(0);
        userframe.setVisible(true);
    }

    private void menuItem_delUserActionPerformed(ActionEvent e) {
        if (userframe==null){
            userframe= new User_Management_Frame(currentUser);
        }
        userframe.setTabSeq(2);
        userframe.setVisible(true);
    }

    private void menuItem_modUserActionPerformed(ActionEvent e) {
        if (userframe==null){
            userframe= new User_Management_Frame(currentUser);
        }
        userframe.setTabSeq(1);
        userframe.setVisible(true);
    }

    private void InitFrame(){
        Toolkit toolkit = getToolkit();                    // 获得Toolkit对象
        Dimension dimension = toolkit.getScreenSize();     // 获得Dimension对象
        int screenHeight = dimension.height;               // 获得屏幕的高度
        int screenWidth = dimension.width;                 // 获得屏幕的宽度
        this.setSize(screenWidth, screenHeight);           // 获得窗体的高度

        this.setLocation(0,0);//覆盖整个屏幕

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        mainPanel = new JPanel();
        getContentPane().add(mainPanel,BorderLayout.CENTER);//将mainPanel放在frame中间
        mainPanel.setLayout(null);
    }

}
