package All.Client.Frame;

import All.Client.App;
import All.Server.DAO.FileDAO;
import All.Domain.*;
import All.Server.Service.FileService;
import All.Socket.Client;
import All.util.CommandTranser;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.sql.Timestamp;
import java.util.List;

public class File_Frame extends Base_Frame {
    FileDAO fileDAO = new FileDAO();
    FileService fileService = new FileService();

    private MyTableModel myTableModel;
    private JTabbedPane tabbedPane1;
    private JPanel mainPanel;
    private JTable table1;
    private JButton upButton;
    private JButton cancelButton;
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JTextField IDTextField;
    private JTextArea DesciptionTextArea;
    private JButton fileChooseButton;
    private JTextField filenameText;
    private JButton downloadButton;
    private JButton backButton;
    private JTextField filePathField;

    public File_Frame(User user){
        currentUser = user;
        setTitle("文件管理界面");
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        setSize(400, 300);
        Toolkit toolkit = getToolkit();
        Dimension dimension = toolkit.getScreenSize();
        int screenHeight = dimension.height;
        int screenWidth = dimension.width;
        int frm_Height = this.getHeight();
        int frm_width = this.getWidth();
        this.setLocation((screenWidth - frm_width) / 2,
                (screenHeight - frm_Height) / 2);
        table1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        table1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        if(currentUser.getRole().equals("browser")||currentUser.getRole().equals("administrator") ){
            tabbedPane1.setEnabledAt(0,false);
        }

        tabbedPane1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                tabbedPane1StateChanged(e);
            }
        });
        upButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                upButtonAction(e);
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonAction(e);
            }
        });
        fileChooseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fileChooseButtonAction(e);
            }
        });
        downloadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                downButtonAction(e);
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backButtonAction(e);
            }
        });
    }
//
//    public static void launch() {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new File_Frame().setVisible(true);
//            }
//        });
//    }

    private void backButtonAction(ActionEvent e) {
        this.dispose();
    }

    private void downButtonAction(ActionEvent e) {
        try {
            if (JOptionPane.showConfirmDialog(this, "确定要下载档案吗？\t\n单击确定按钮将下载。", "确认对话框", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                int currentRow = table1.getSelectedRow();
                String docID = "";
                String filename = "";
                Object object = myTableModel.getValueAt(currentRow,0);
                if(object !=null){
                    docID = object.toString().trim();  //档案号
                    filename = (String)myTableModel.getValueAt(currentRow,3);
                }
                int id = Integer.parseInt(docID);
                FileDialog dlg_save=new FileDialog(this," 保存文件",FileDialog.SAVE);
                dlg_save.setFile(filename);
                dlg_save.setVisible(true);
                if(dlg_save.getFile()!=null){
                    File downFile = new File(dlg_save.getDirectory(),dlg_save.getFile());//目标文件
                    CommandTranser commandTranser;
                    commandTranser = Client.transer("findFile", id);
                    MyFile myfile =(MyFile) commandTranser.getData();
                    commandTranser = Client.transer("downloadFile", myfile);
                    myfile = (MyFile)commandTranser.getData();
                    FileOutputStream fos = new FileOutputStream(downFile);
                    BufferedOutputStream bos = new BufferedOutputStream(fos);
                    bos.write(myfile.getFileContent());

                    JOptionPane.showMessageDialog(this, commandTranser.getResult());
                    fos.close();
                    bos.close();
                }
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "下载失败！");
        }
    }

    private void fileChooseButtonAction(ActionEvent e) {
        FileDialog dlg_open=new FileDialog(this,"打开文件对话框",FileDialog.LOAD);
        dlg_open.setVisible(true);
        if(dlg_open.getFile()!=null){
            filePathField.setText(dlg_open.getDirectory());
            filenameText.setText(dlg_open.getFile());
        }

    }

    public void setTabSeq(int index){
        tabbedPane1.setSelectedIndex(index);
    }

    private void cancelButtonAction(ActionEvent evt){
        IDTextField.setText("");
        filenameText.setText("");
        DesciptionTextArea.setText("");
    }

    private void upButtonAction(ActionEvent evt) {
        String filename=filenameText.getText();
        String description= DesciptionTextArea.getText();
        String filepath = filePathField.getText();

        FileInputStream fis = null;
        BufferedInputStream bis = null;

        try {
            fis = new FileInputStream(new File(filepath+filename));
            // fis.available返回文件的总大小
            byte[] fcontent = new byte[fis.available()];
            bis = new BufferedInputStream(fis);
            bis.read(fcontent);
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            MyFile myFile = new MyFile(filename, currentUser.getUsername(),timestamp,description, fcontent);

            if (JOptionPane.showConfirmDialog(this, "确定上传档案吗？\t\n单击确定按钮将上传。", "确认对话框", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {

                CommandTranser commandTranser;
                commandTranser = Client.transer("uploadFile", myFile);

                JOptionPane.showMessageDialog(this, commandTranser.getResult());

                IDTextField.setText("");
                filenameText.setText("");
                DesciptionTextArea.setText("");
            }
        }catch(Exception ex){
            ex.printStackTrace();
        } finally {
            if (bis != null)
                try {
                    bis.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    private void tabbedPane1StateChanged(ChangeEvent e) {
        if(tabbedPane1.getSelectedIndex() == 1){
            showFileIntoTable();
        }
    }

    private void showFileIntoTable() {
        try {
            String[] colName = {"档案号", "文件名", "用户名", "时间", "描述"};
            String[][] tableValue = new String[20][5];

            CommandTranser commandTranser;
            commandTranser = Client.transer("findAllFiles",null);

            List<MyFile> myFiles =(List<MyFile>) commandTranser.getData();
            for (int row = 0; row < myFiles.size(); row++) {
                MyFile myFile = myFiles.get(row);
                tableValue[row][0] = myFile.getId() + "";
                tableValue[row][1] = myFile.getFilename();
                tableValue[row][2] = myFile.getUsername();
                tableValue[row][3] = (myFile.getTimestamp()).toString();
                tableValue[row][4] = myFile.getDescription();
            }
             myTableModel = new MyTableModel(tableValue, colName);
            table1.setModel(myTableModel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
