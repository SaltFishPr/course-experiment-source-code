package All.Client.Frame;

import All.Client.App;
import All.Domain.User;
import All.Server.DAO.UserDao;
import All.Socket.Client;
import All.util.CommandTranser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class System_Login_Frame extends Base_Frame {
    private JTextField username;
    private JPasswordField password;
    private JButton login;
    private JPanel system_loginPanel;
    private JButton exit;

    /**
     * 登录界面
     */
    public System_Login_Frame() {
        setTitle("系统登录");
        getContentPane().add(system_loginPanel, BorderLayout.CENTER);
        setSize(300, 200);
        Toolkit toolkit = getToolkit();                    // 获得Toolkit对象
        Dimension dimension = toolkit.getScreenSize();     // 获得Dimension对象
        int screenHeight = dimension.height;               // 获得屏幕的高度
        int screenWidth = dimension.width;                 // 获得屏幕的宽度
        int frm_Height = this.getHeight();                 // 获得窗体的高度
        int frm_width = this.getWidth();                   // 获得窗体的宽度
        this.setLocation((screenWidth - frm_width) / 2, (screenHeight - frm_Height) / 2);          // 使用窗体居中显示
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String userName = username.getText().trim();
                String passWord = String.valueOf(password.getPassword()).trim();

                User user = new User();
                user.setUsername(userName);
                user.setPassword(passWord);
                //信息交互
                CommandTranser commandTranser;
                commandTranser = Client.transer("login",user);
                if (!commandTranser.isFlag()) {
                    JOptionPane.showMessageDialog(null, "用户名或密码错误，请重新输入！", "提示", JOptionPane.WARNING_MESSAGE);
                }
                else {
                    user =(User) commandTranser.getData();
                    currentUser = new User(user.getUsername(),user.getPassword(),user.getRole());
                    hideFrame();
                    Main_Frame mainframe = new Main_Frame(currentUser);
                    mainframe.setVisible(true);
                }
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(1);
            }
        });
    }

    private void hideFrame() {
        this.dispose();
    }

}
