package All.Server.Service;

import All.Domain.User;
import All.Server.DAO.UserDao;

/**
 * 	用户服务类
 */
public class UserService {
    private UserDao userDao = new UserDao();

    //检测账户在数据库是否存在
    public synchronized User checkUser(User user) {
        String username = user.getUsername();
        String password = user.getPassword();
        user = userDao.findUser(username,password);
        return user;
    }
    //在数据库中添加注册的用户
    public synchronized boolean addUser(User user) {
        return userDao.insert(user);
    }
    //在数据库中删除用户
    public synchronized boolean deleteUser(User user){
        return userDao.delete(user);
    }
    //在数据库中修改用户
    public synchronized boolean updateUser(User user){
        return userDao.update(user);
    }
}

