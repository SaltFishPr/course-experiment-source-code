package All.Server.Service;

import All.Constants;
import All.Domain.*;
import All.Server.DAO.FileDAO;

import java.io.*;

/**
 * 文件服务类
 */
public class FileService {
    FileDAO fileDAO = new FileDAO();
    private String uploadPath = Constants.UPLOAD_PATH;

    public  boolean uploadFile(MyFile myFile){
        try {
            File downFile = new File(uploadPath + myFile.getUsername());
            if(!downFile.exists())
            {
                downFile.mkdir();
            }
            downFile = new File(uploadPath + myFile.getUsername() +"\\"+ myFile.getFilename());
            FileOutputStream fos = new FileOutputStream(downFile);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            bos.write(myFile.getFileContent());
            myFile.setFileContent(new byte[1]);
            fileDAO.insert(myFile);

            fos.close();
            bos.close();
        }catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    //下载文件（未选定目标文件）
    public  boolean downloadFile (MyFile myFile) {
        try {
            myFile.assign(fileDAO.findByID(myFile.getId()));
            File file = new File(uploadPath + myFile.getUsername() + "\\" + myFile.getFilename());
            FileInputStream fis = new FileInputStream(file);
            // fis.available返回文件的总大小
            byte[] fcontent = new byte[fis.available()];
            BufferedInputStream bis = new BufferedInputStream(fis);
            bis.read(fcontent);
            myFile.setFileContent(fcontent);
            fis.close();
            bis.close();
        }catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
        return true;
    }
}
