package All.Server.DAO;

import All.Constants;

import java.sql.*;

public class BaseDAO {
    protected String driver = Constants.DB_DRIVER;
    protected String url = Constants.DB_CONNECTION;
    protected String user = Constants.DB_USER;
    protected String password = Constants.DB_PASSWORD;

    protected Connection getConnection() throws SQLException    //建立与数据库的连接
    {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(url, user, password);
    }
    protected void closeConnection(Connection connection) {
        if (connection != null)
        {
            try
            {
                connection.close();
            }
            catch (SQLException e)
            {
                System.out.println("连接断开错误");
            }
            connection = null;
        }
    }

    protected void closeResultSet(ResultSet resultSet) {
        if (resultSet != null)
        {
            try
            {
                resultSet.close();
            }
            catch (SQLException e)
            {
                System.out.println("断开错误resultSet");
            }
            resultSet = null;
        }
    }

    protected void closeStatement(Statement statement) {
        if (statement != null)
        {
            try
            {
                statement.close();
            }
            catch (SQLException e)
            {
                System.out.println("断开错误statement");
            }
            statement = null;
        }
    }
}
