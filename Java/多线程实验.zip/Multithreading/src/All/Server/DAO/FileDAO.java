package All.Server.DAO;

import All.Domain.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FileDAO extends BaseDAO {

    public synchronized boolean insert(MyFile myFile) { //上传文件
        Connection connection = null;
        PreparedStatement preparedStatement1 = null;
        PreparedStatement preparedStatement2 = null;
        ResultSet resultSet = null;
        int count=1;
        try {
            connection = getConnection();
            String sql = "insert into file_info (id,filename,username,timestamp,fcontent,description) values(?,?,?,?,?,?)";
            String sql_select = (" select * from file_info");
            preparedStatement1 = connection.prepareStatement(sql);
            preparedStatement2 = connection.prepareStatement(sql_select);
            resultSet=preparedStatement2.executeQuery();
            while(resultSet.next()){
                count++;
            }
            preparedStatement1.setInt(1, count);
            preparedStatement1.setString(2, myFile.getFilename().trim());
            preparedStatement1.setString(3, myFile.getUsername().trim());
            preparedStatement1.setTimestamp(4, myFile.getTimestamp());
            preparedStatement1.setBytes(5, myFile.getFileContent());
            preparedStatement1.setString(6,myFile.getDescription());
            int n=preparedStatement1.executeUpdate();
            if(n>0){
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally{
            try {
                if(connection!=null)
                    connection.close();
                if(preparedStatement1!=null)
                    preparedStatement1.close();
                if(preparedStatement2!=null)
                    preparedStatement2.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return false;
    }

    public void update(MyFile myFile){  //更新文件
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("update file_info set filename=?,username=?,timestamp=?,fcontent=? ,description = ? where id=?");
            preparedStatement.setString(1, myFile.getFilename());
            preparedStatement.setString(2, myFile.getUsername());
            preparedStatement.setTimestamp(3, myFile.getTimestamp());
            preparedStatement.setBytes(4, myFile.getFileContent());
            preparedStatement.setString(5,myFile.getDescription());
            preparedStatement.setInt(6, myFile.getId());

            int rt = preparedStatement.executeUpdate();
            if (rt <= 0) {

            }
        }catch(SQLException ex) {
            ex.printStackTrace();
        }finally {
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
    }

    public void delete(MyFile myFile){  //删除文件
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("delete from file_info where id=?");
            preparedStatement.setInt(1, myFile.getId());
            int rt = preparedStatement.executeUpdate();
            if (rt > 0) {

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
    }

    public MyFile findByID(int id){
        Connection connection = null;
        PreparedStatement preparedStatement = null, pstmt1 = null;
        ResultSet resultSet = null, resultSet1 = null;

        MyFile myFile = null;

        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from file_info where id=?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                myFile = new MyFile();
                myFile.setId(resultSet.getInt("id"));
                myFile.setFilename(resultSet.getString("filename"));
                myFile.setUsername(resultSet.getString("username"));
                myFile.setTimestamp(resultSet.getTimestamp("timestamp"));
                myFile.setFileContent(resultSet.getBytes("fcontent"));
                myFile.setDescription(resultSet.getString("description"));

//                pstmt1 = connection.prepareStatement("select * from user_info where username=?");
//                pstmt1.setString(1, resultSet.getString("username"));
//                resultSet1 = pstmt1.executeQuery();
//                if (resultSet1.next()) {
//                    User user = new User();
//                    user.setUsername(resultSet1.getString("username"));
//                    user.setPassword(resultSet1.getString("password"));
//                    user.setRole(resultSet1.getString("role"));
//                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeResultSet(resultSet1);
            closeStatement(pstmt1);
            closeConnection(connection);
        }
        return myFile;
    }

    public List<MyFile> findAllOnes() {
        List<MyFile> MyFiles = new ArrayList<MyFile>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from file_info");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int document_id = rs.getInt("id");
                MyFile document = this.findByID(document_id);
                MyFiles.add(document);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeResultSet(rs);
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return MyFiles;
    }

}
