package All.Server.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import All.Domain.*;

public class UserDao extends BaseDAO {

    public boolean insert(User object){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("insert into user_info (username, password, role) values (?,?,?)",Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1,object.getUsername());
            preparedStatement.setString(2,object.getPassword());
            preparedStatement.setString(3,object.getRole());
            int x = preparedStatement.executeUpdate();
            if (x > 0) {
                return true;
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            return false;
        }finally{
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return false;
    }

    public boolean update(User object){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("update user_info set password=?,role=? where username=?");
            preparedStatement.setString(1,object.getPassword());
            preparedStatement.setString(2,object.getRole());
            preparedStatement.setString(3,object.getUsername());
            int x = preparedStatement.executeUpdate();
            if (x > 0) {
                return true;
            }
        }catch(SQLException ex){
            ex.printStackTrace();
            return false;
        }finally{
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return false;
    }

    public boolean delete(User object){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("delete from user_info where username=?");
            preparedStatement.setString(1,object.getUsername());
            int x = preparedStatement.executeUpdate();
            if (x > 0) {
                return true;
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            return false;
        }finally{
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return false;
    }
    public User findByName(String name){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        User user = new User();

        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from user_info where username=?");
            preparedStatement.setString(1,name);
            resultSet = preparedStatement . executeQuery();
            if(resultSet.next()){
                user.setUsername(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return user;
    }

    public User findUser(String username,String password){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        User user = null;

        try {
            connection = getConnection();
            String sql = "select * from user_info where username =? and password=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement . executeQuery();
            if(resultSet.next()){
                user = new User();
                user.setUsername(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return user;
    }

    public List<User> findAllOnes() {
        List<User> users = new ArrayList<User>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try{
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from user_info");
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                User user = new User();
                user.setUsername(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
                users.add(user);
            }
        }catch (SQLException ex){
            System.out.println("数据库错误！");
        }finally{
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection(connection);
        }
        return users;
    }

}
