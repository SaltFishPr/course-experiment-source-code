package All.Socket;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import All.Client.Frame.System_Login_Frame;
import All.util.CommandTranser;

/**
 * 客户端
 */
public class Client {
    public static Socket socket=null;
    public static int port=8888;
    public static String address="127.0.0.1";

    //连接服务器
    public static void getConnect(){
        try{
            socket = new Socket(address,port);
        } catch (IOException ex){
            ex.printStackTrace();
            System.out.println("未找到服务器！");
        }
    }
    //获得服务器的数据
    public static CommandTranser getData() {
        // TODO Auto-generated method stub
        ObjectInputStream ois=null;
        CommandTranser res=null;
        try {
            ois=new ObjectInputStream(Client.socket.getInputStream());
            res=(CommandTranser) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally{
            if(ois!=null){
                try {
                    ois.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return res;
    }
    //向服务器发送数据
    public static void sendData(CommandTranser cmd) {
        // TODO Auto-generated method stub
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(Client.socket.getOutputStream());
            oos.writeObject(cmd);

            oos.flush();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //断开连接
    public static void closeConnect(){
        try{
            socket.close();
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    public static CommandTranser transer(String cmd,Object object){
        Client.getConnect();
        CommandTranser commandTranser = new CommandTranser();
        commandTranser.setCmd(cmd);
        commandTranser.setData(object);
        Client.sendData(commandTranser);
        commandTranser = Client.getData();
        Client.closeConnect();
        return commandTranser;
    }

}
