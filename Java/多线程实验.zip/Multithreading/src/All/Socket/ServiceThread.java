package All.Socket;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import All.Domain.*;
import All.Server.DAO.FileDAO;
import All.Server.DAO.UserDao;
import All.Server.Service.*;
import All.util.CommandTranser;

/**
 *	服务器线程
 */
public class ServiceThread implements Runnable {
    private Socket socket;
    public ServiceThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;
        try {
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());
            CommandTranser cmd=(CommandTranser) ois.readObject();
            //处理客户端发送来的数据
            cmd=execute(cmd);
            //发送处理后的数据
            oos.writeObject(cmd);
            oos.flush();
        } catch (IOException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally{
            try {
                if(ois!=null)
                    ois.close();
                if(oos!=null){
                    oos.close();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
    //处理客户端发送来的数据
    private CommandTranser execute(CommandTranser cmd) {
        // TODO Auto-generated method stub
        //客户端登录操作
        if("login".equals(cmd.getCmd())){
            UserService userService=new UserService();
            User user=(User) cmd.getData();
            user = userService.checkUser(user);
            cmd.setData(user);
            if(user!=null){
                cmd.setFlag(true);
            }else{
                cmd.setFlag(false);
            }
            if(cmd.isFlag()){
                cmd.setResult("登录成功！！");
            }else{
                cmd.setResult("登录失败!!!");
            }
        }
        //客户端注册用户操作
        if("register".equals(cmd.getCmd())){
            UserService userService=new UserService();
            User user=(User) cmd.getData();
            cmd.setFlag(userService.addUser(user));
            if(cmd.isFlag()){
                cmd.setResult("注册成功，请登录!");
            }else{
                cmd.setResult("注册失败!!!");
            }
        }
        //客户端查找用户操作
        if("find".equals(cmd.getCmd())){
            UserDao userDao = new UserDao();
            String username=(String) cmd.getData();
            User user = userDao.findByName(username);
            if(user!=null){
                cmd.setData(userDao.findByName(username));
            }
        }
        //客户端查找所有用户操作
        if("findAllOnes".equals(cmd.getCmd())){
            UserDao userDao = new UserDao();
            List<User> users = userDao.findAllOnes();
            if(users!=null){
                cmd.setData(users);
            }
        }
        //客户端修改用户操作
        if("updateUser".equals(cmd.getCmd())){
            UserService userService=new UserService();
            User user=(User) cmd.getData();
            cmd.setFlag(userService.updateUser(user));
            if(cmd.isFlag()){
                cmd.setResult("修改成功!");
            }else{
                cmd.setResult("修改失败!");
            }
        }
        //客户端删除用户操作
        if("deleteUser".equals((cmd.getCmd()))){
            UserService userService=new UserService();
            User user=(User) cmd.getData();
            cmd.setFlag(userService.deleteUser(user));
            if(cmd.isFlag()){
                cmd.setResult("删除用户成功！");
            }
            else{
                cmd.setResult("删除用户失败！");
            }
        }
        //客户端修改个人信息操作
        if("changeSelfInfo".equals(cmd.getCmd())){
            UserService userService=new UserService();
            User user=(User) cmd.getData();
            cmd.setFlag(userService.updateUser(user));
            if(cmd.isFlag()){
                cmd.setResult("修改成功！");
            }
            else{
                cmd.setResult("修改失败！");
            }
        }
        //客户端上传文件操作
        if("uploadFile".equals(cmd.getCmd())){
            FileService fileService = new FileService();
            MyFile myFile =(MyFile) cmd.getData();
            cmd.setFlag(fileService.uploadFile(myFile));
            if(cmd.isFlag()){
                cmd.setResult("上传文件成功!");
            }else{
                cmd.setResult("上传文件失败！");
            }
        }
        //客户端下载文件操作
        if("downloadFile".equals(cmd.getCmd())){
            FileService fileService = new FileService();
            MyFile myFile =(MyFile) cmd.getData();
            cmd.setFlag(fileService.downloadFile(myFile));
            cmd.setData(myFile);
            if(cmd.isFlag()){
                cmd.setResult("下载文件成功!");
            }else{
                cmd.setResult("下载文件失败！");
            }
        }
        //客户端查找文件操作
        if("findFile".equals(cmd.getCmd())){
            FileDAO fileDAO = new FileDAO();
            int id = (int) cmd.getData();
            MyFile myFile = fileDAO.findByID(id);
            if(myFile!=null){
                cmd.setData(myFile);
            }
        }
        //查找所有文件
        if("findAllFiles".equals(cmd.getCmd())){
            FileDAO fileDAO = new FileDAO();
            List<MyFile> myFiles = fileDAO.findAllOnes();
            if(myFiles!=null){
                cmd.setData(myFiles);
            }
        }

        return cmd;
    }

}
