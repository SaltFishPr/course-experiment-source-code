package All.Domain;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 文件的实体类
 */
public class MyFile implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;             //id
    private String filename;    //文件名
    private String username;    //创建用户
    private Timestamp timestamp;//时间戳
    private byte[] fileContent; //文件内容
    private String description; //文件描述
    public MyFile() {
        super();
        // TODO Auto-generated constructor stub
    }

    public MyFile(String filename, String username, Timestamp timestamp, String description,byte[] fileContent) {
        super();
        this.filename = filename;
        this.username = username;
        this.timestamp = timestamp;
        this.description = description;
        this.fileContent = fileContent;
    }

    public void assign(MyFile myFile){
        this.filename = myFile.getFilename();
        this.username = myFile.getUsername();
        this.timestamp = myFile.getTimestamp();
        this.description = myFile.getDescription();
        this.fileContent = myFile.getFileContent();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
