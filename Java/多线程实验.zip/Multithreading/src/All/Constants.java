package All;

public interface Constants {
    static final String UPLOAD_PATH = "D:\\java-practice\\experiment\\Multithreading\\data\\serviceFile\\";
    static final String UPLOAD_TEMP_PATH = "d:\\OOP\\uploadfile\\temp\\";
    static final String DOWNLOAD_PATH = "D:\\java-practice\\experiment\\Multithreading\\data\\localFile\\";

    static final String DOCUMENT_FILE = "d:\\OOP\\document.bin";
    static final String USER_FILE = "d:\\OOP\\user.bin";

    static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_CONNECTION = "jdbc:mysql://localhost/document?useSSL = false&serverTimezone = UTC&";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "99624";
}

